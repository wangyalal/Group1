import scrapy

class RepoItem(scrapy.Item):
    repo_name = scrapy.Field()
    url = scrapy.Field()
    about = scrapy.Field()
    last_updated = scrapy.Field()
    languages = scrapy.Field()
    commits = scrapy.Field()