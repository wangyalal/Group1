import scrapy
from myproject.items import RepoItem


class GithubSpider(scrapy.Spider):
    name = "github_spider"
    allowed_domains = ["github.com"]

    github_username = "owenkosisk06-ui"

    start_urls = [f"https://github.com/owenkosisk06-ui?tab=repositories"]

    headers = {
        "User-Agent": "Mozilla/5.0",
        "Accept-Language": "en-US,en;q=0.9",
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, headers=self.headers, callback=self.parse)

    def parse(self, response):
        # find ALL links that belong to your username
        links = response.xpath(f'//a[contains(@href, "/{self.github_username}/")]/@href').getall()

        repo_links = []

        for link in links:
            # keep only repo links (format: /username/repo)
            if link.count("/") == 2:
                repo_links.append(link)

        # remove duplicates
        repo_links = list(set(repo_links))

        print("Found repos:", len(repo_links))  # DEBUG

        for link in repo_links:
            yield response.follow(link, callback=self.parse_repo, headers=self.headers)

    def parse_repo(self, response):
        item = RepoItem()

        repo_name = response.url.split("/")[-1]
        item["repo_name"] = repo_name
        item["url"] = response.url

        about = response.css("p.f4.my-3::text").get()
        if about:
            about = about.strip()

        page_text = " ".join(response.css("body *::text").getall()).lower()
        is_empty = "this repository is empty" in page_text

        if not about and not is_empty:
            about = repo_name
        elif is_empty:
            about = None

        item["about"] = about

        item["last_updated"] = response.css("relative-time::attr(datetime)").get()

        if not is_empty:
            languages = response.css('span[itemprop="programmingLanguage"]::text').getall()
            languages = [l.strip() for l in languages if l.strip()]
            item["languages"] = ", ".join(languages) if languages else None
        else:
            item["languages"] = None

        if not is_empty:
            commits = response.xpath('//a[contains(@href,"commits")]/span/text()').get()
            if commits:
                commits = commits.strip().replace(",", "")
        else:
            commits = None

        item["commits"] = commits

        yield item