# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class RepospiderItem(scrapy.Item):
    User = scrapy.Field()
    Url = scrapy.Field()
    Name = scrapy.Field()
    About = scrapy.Field()
    Language = scrapy.Field()
    Commit_Count = scrapy.Field()
    Last_Update = scrapy.Field()
