import scrapy
from repospider.items import RepospiderItem

class GithubreposcraperSpider(scrapy.Spider):
    name = "githubreposcraper"
    allowed_domains = ["github.com"]
    start_urls = ["https://github.com/adhamilton2700?tab=repositories",
                  "https://github.com/trungvdhp?tab=repositories"]

    def parse(self, response):
        username = response.url.split('/')[-1].split('?')[0]
        repos = response.css('div.col-10.col-lg-9.d-inline-block')
        for repo in repos:  
            repo_url=repo.css('h3 a::attr(href)').get()
            last_upd = repo.css('relative-time::attr(datetime)').get()
            yield response.follow(repo_url, callback=self.rep_parse, 
                                  cb_kwargs={'last_upd':last_upd, 'user':username})

    def rep_parse(self, response, last_upd, user):

        repo_item=RepospiderItem()

        repo_item['User'] = user
        repo_item['Url'] = response.url
        repo_item['Name'] = response.css('strong a::text').get()
        repo_item['About'] = response.css('p.f4.tmp-my-3::text').get(default=repo_item['Name']).strip()
        repo_item['Language'] = response.css('span.color-fg-default::text').getall() or 'none'
        repo_item['Commit_Count'] = response.css('span.fgColor-default::text').get(default='none')
        repo_item['Last_Update'] = last_upd

        yield repo_item