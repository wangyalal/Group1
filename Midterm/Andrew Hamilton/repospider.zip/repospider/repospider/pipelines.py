# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from datetime import datetime

class RepospiderPipeline:
    def process_item(self, item, spider):
        
        adapter = ItemAdapter(item)
        
        #date cleanup
        date = adapter.get('Last_Update')
        date_obj = datetime.fromisoformat(date.replace('Z', '+00:00'))
        adapter['Last_Update'] = date_obj.strftime('%d-%B-%Y, at %H:%M:%S')

        return item