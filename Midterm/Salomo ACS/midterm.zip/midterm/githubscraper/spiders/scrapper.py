import scrapy
from githubscraper.items import GithubItem 

class GitHubSpider(scrapy.Spider):
    name = "github"

    start_urls = [
        "https://github.com/salacs?tab=repositories",
        "https://github.com/salomosin?tab=repositories",
        "https://github.com/trungvdhp?tab=repositories"
    ]

    def parse(self, response):
        repos = response.css("div#user-repositories-list li")

        for repo in repos:
            path = repo.css("h3 a::attr(href)").get()
            if not path:
                continue
                
            repo_url = response.urljoin(path)
            about = repo.css("p[itemprop='description']::text").get()
            if about:
                about = about.strip()

            yield response.follow(
                repo_url,
                self.parse_repo,
                meta={"about": about}
            )

        next_page = response.css("a.next_page::attr(href)").get()
        if next_page:
            yield response.follow(next_page, self.parse)

    def parse_repo(self, response):
        item = GithubItem()

        # Fill the Item with data
        item["url"] = response.url
        item["name"] = response.xpath("//strong[@itemprop='name']/a/text()").get()
        item["about"] = response.meta.get("about")
        item["language"] = response.css("span[itemprop='programmingLanguage']::text").get()
        item["last_updated"] = response.css("relative-time::attr(datetime)").get()

        yield item