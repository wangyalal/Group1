# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from datetime import datetime


class GithubScraperPipeline:
    def process_item(self, repo_info, spider):
        adapter = ItemAdapter(repo_info)

        raw_date = adapter.get('Last_Update')
        dt = datetime.fromisoformat(raw_date.replace('Z', '+00:00'))
        adapter['Last_Update'] = dt.strftime('%Y-%m-%d %H:%M:%S')


        return repo_info
