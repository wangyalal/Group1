import scrapy
from datetime import datetime
from github_scraper.items import GithubItem

#scrapes github and defines the name of the scraper, allowed domains and where to start scraping. 
class GithubSpider(scrapy.Spider):
    name = "github" 
    allowed_domains = ['github.com'] 
    start_urls = ["https://github.com/trungvdhp?tab=repositories"]

#Loops through all repos and then calls step_in_repo to scrape the contents inside   
    def parse(self, response):
        repos = response.css('li[itemprop="owns"]')

        for repo in repos:            
            in_repo = repo.css('h3.wb-break-all a::attr(href)').get()
            last_update = repo.css('relative-time::attr(datetime)').get()
            if in_repo:
                 yield response.follow(in_repo, callback = self.step_in_repo, cb_kwargs= {'last_update' : last_update}) 

#scrapes information from within the repository
    def step_in_repo(self, response, last_update):

        #items defined
        repo_info = GithubItem()
        repo_info['Commits'] = response.css('span.fgColor-default::text').get(default = "None")
        repo_info['Languages'] = response.css('span.color-fg-default::text').getall() or 'None'            
        repo_info['Name'] = response.xpath('//strong[@itemprop="name"]/a/text()').get().strip()
        repo_info['About'] = response.css('p.tmp-my-3::text').get(default= repo_info['Name']).strip()
        repo_info['Url'] = response.xpath('//meta[@property="og:url"]/@content').get()
        repo_info['Last_Update'] = last_update
        yield repo_info
