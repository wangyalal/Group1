# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class GithubItem(scrapy.Item):
    # define the fields for your item here like:
    Url = scrapy.Field()
    About = scrapy.Field()
    Languages = scrapy.Field()
    Commits = scrapy.Field()
    Last_Update = scrapy.Field()
    Name = scrapy.Field()

