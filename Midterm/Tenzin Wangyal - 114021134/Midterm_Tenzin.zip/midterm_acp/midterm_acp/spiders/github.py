import scrapy
from scrapy.loader import ItemLoader
from midterm_acp.items import RepoItem
from itemloaders.processors import TakeFirst, MapCompose

class GithubSpider(scrapy.Spider):
    name = "github"
    allowed_domains = ["github.com"]
    start_urls = ["https://github.com/wangyalal?tab=repositories"]

    def parse(self, response):
        repositories = response.css('li[itemprop="owns"]')
        for repo in repositories:
            loader = ItemLoader(item=RepoItem(), selector=repo)
            
            href = repo.css('h3 a::attr(href)').get()
            full_url = response.urljoin(href)
            loader.add_value('url', full_url)
            
            loader.add_css('about', 'p[itemprop="description"]::text')
            loader.add_css('about', 'h3 a::text')
            loader.add_css('last_updated', 'relative-time::attr(datetime)')
            loader.add_css('languages', 'span[itemprop="programmingLanguage"]::text')

            yield scrapy.Request(
                full_url, 
                callback=self.parse_repo_details, 
                meta={'loader': loader}
            )

    def parse_repo_details(self, response):
        loader = response.meta['loader']
        
        commits = response.css('span.d-none.d-sm-inline strong::text').get()
        
        if commits:
            loader.add_value('commits', commits)
        else:
            loader.add_value('commits', '0')

        yield loader.load_item()


