import psycopg2

class PostgresPipeline:
    def open_spider(self, spider):
        self.conn = psycopg2.connect(
            host="localhost",
            database="your_db",
            user="your_user",
            password="your_password"
        )
        self.cur = self.conn.cursor()
        self.cur.execute("""
            CREATE TABLE IF NOT EXISTS github_repos(
                id serial PRIMARY KEY,
                url text,
                about text,
                last_updated text,
                languages text,
                commits text
            )
        """)

    def process_item(self, item, spider):
        self.cur.execute("""
            INSERT INTO github_repos (url, about, last_updated, languages, commits)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            item['url'],
            item['about'],
            item['last_updated'],
            str(item['languages']),
            item['commits']
        ))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cur.close()
        self.conn.close()