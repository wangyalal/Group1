import scrapy
from itemloaders.processors import TakeFirst, MapCompose

def clean_data(value):
    return value.strip() if value else None

class RepoItem(scrapy.Item):
    url = scrapy.Field(
        input_processor=MapCompose(clean_data),
        output_processor=TakeFirst()
    )
    about = scrapy.Field(
        input_processor=MapCompose(clean_data),
        output_processor=TakeFirst()
    )
    last_updated = scrapy.Field(
        output_processor=TakeFirst()
    )
    languages = scrapy.Field(
        input_processor=MapCompose(clean_data),
        output_processor=TakeFirst()
    )
    commits = scrapy.Field(
        output_processor=TakeFirst()
    )